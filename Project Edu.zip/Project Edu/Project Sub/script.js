
document.addEventListener('DOMContentLoaded', function() {
// File Upload Handling
const fileUpload = document.getElementById('fileUpload');
const fileInput = document.getElementById('fileInput');
const filePreview = document.getElementById('filePreview');
const progressContainer = document.getElementById('progressContainer');
const progressFill = document.getElementById('progressFill');
const progressPercentage = document.getElementById('progressPercentage');
const projectForm = document.getElementById('projectForm');
const successAlert = document.getElementById('successAlert');
const errorAlert = document.getElementById('errorAlert');
const submitBtn = document.getElementById('submitBtn');

// Add animation class with delay to feature cards
const featureCards = document.querySelectorAll('.feature-card');
featureCards.forEach((card, index) => {
    setTimeout(() => {
        card.classList.add('animate');
    }, 200 * (index + 1));
});

// File upload click handler
fileUpload.addEventListener('click', function() {
    fileInput.click();
});

// Drag and drop handlers
fileUpload.addEventListener('dragover', function(e) {
    e.preventDefault();
    fileUpload.style.borderColor = '#00c896';
});

fileUpload.addEventListener('dragleave', function() {
    fileUpload.style.borderColor = '#ddd';
});

fileUpload.addEventListener('drop', function(e) {
    e.preventDefault();
    fileUpload.style.borderColor = '#ddd';
    handleFiles(e.dataTransfer.files);
});

// File input change handler
fileInput.addEventListener('change', function() {
    handleFiles(this.files);
});

// Handle selected files
function handleFiles(files) {
    if (files.length > 0) {
        filePreview.style.display = 'block';
        filePreview.innerHTML = '';
        
        // Limit to 5 files
        const maxFiles = Math.min(files.length, 5);
        
        for (let i = 0; i < maxFiles; i++) {
            const file = files[i];
            
            // Check file size (max 10MB)
            if (file.size > 10 * 1024 * 1024) {
                alert(`File "${file.name}" exceeds the maximum size of 10MB.`);
                continue;
            }
            
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item';
            
            // Get file icon based on type
            let fileIcon = '📄';
            if (file.type.includes('image')) fileIcon = '🖼️';
            else if (file.name.endsWith('.zip')) fileIcon = '📦';
            else if (file.name.endsWith('.pdf')) fileIcon = '📑';
            
            fileItem.innerHTML = `
                <span>${fileIcon}</span>
                <span class="file-item-name">${file.name}</span>
                <span class="file-item-remove">×</span>
            `;
            
            filePreview.appendChild(fileItem);
            
            // Remove file handler
            fileItem.querySelector('.file-item-remove').addEventListener('click', function() {
                fileItem.remove();
                if (filePreview.children.length === 0) {
                    filePreview.style.display = 'none';
                }
            });
        }
    }
}

// Form submission handler
projectForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Validate form fields
    const requiredFields = projectForm.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.style.borderColor = 'var(--error)';
            isValid = false;
        } else {
            field.style.borderColor = '#ddd';
        }
    });
    
    if (!isValid) {
        showAlert('error', 'Please fill in all required fields.');
        return;
    }
    
    // Show progress animation
    progressContainer.style.display = 'block';
    submitBtn.disabled = true;
    
    // Simulate upload progress
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress > 100) progress = 100;
        
        progressFill.style.width = `${progress}%`;
        progressPercentage.textContent = `${Math.round(progress)}%`;
        
        if (progress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
                progressContainer.style.display = 'none';
                showAlert('success', 'Your project has been submitted successfully! We\'ll review it and get back to you soon.');
                projectForm.reset();
                filePreview.innerHTML = '';
                filePreview.style.display = 'none';
                submitBtn.disabled = false;
            }, 800);
        }
    }, 300);
});

// Show alert message
function showAlert(type, message) {
    const alert = type === 'success' ? successAlert : errorAlert;
    alert.textContent = message;
    alert.style.display = 'block';
    
    // Hide after 5 seconds
    setTimeout(() => {
        alert.style.display = 'none';
    }, 5000);
    
    // Scroll to alert
    alert.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// Add animation to cards when they come into view
const animateOnScroll = () => {
    const elements = document.querySelectorAll('.card, .feature-card');
    elements.forEach(element => {
        const elementPosition = element.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;
        
        if (elementPosition < windowHeight - 100) {
            element.classList.add('animate');
        }
    });
};

// Trigger animation on scroll
window.addEventListener('scroll', animateOnScroll);
animateOnScroll(); // Initial check
});